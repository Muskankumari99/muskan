// cypress/support/index.js
import '@cypress/code-coverage/support'

