describe('view Booked Tickets by movie', () => {
  it('BookedTicketsByMovie', () => {
    cy.visit('http://localhost:3000/bookedTickets/jkl')
  })
})